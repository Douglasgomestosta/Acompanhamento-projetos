<?php
session_start();
require '../sistema/db.php'; 
require '../sistema/FUNCTIONS.php'; 
if(!$_SESSION['logado'] == 1)
{
    echo "0";
    exit();
}
sleep(3);
echo "1";
?>